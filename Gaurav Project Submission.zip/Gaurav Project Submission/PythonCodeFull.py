#Python Program to Clean and Transform Data from csv file for Data Warehousing Project.
#Author -> Gaurav Chakraverty

import numpy as np
import pandas as pd
from numpy import nan
from pandas import read_csv

df=pd.read_csv('adult-training.csv',header=None, sep=',\s', na_values=["?"])
df.replace('?', np.NaN, inplace=True)
df=df.dropna(axis='rows')
df.to_csv("adult-trainingcleaned.csv", header=None);

dfc=pd.read_csv('adult-trainingcleaned.csv',header=None, sep=',')
dfc[0] = ""
demp = dfc[[0,7,2,10]]

for x in range(0,(len(demp[2]))):
    if (demp[2][x] == 'Federal-gov') or (demp[2][x] == 'Local-gov') or (demp[2][x] == 'State-gov'):
        demp[2][x] = 'Gov-Sector'
    elif (demp[2][x] == 'Self-emp-not-inc') or (demp[2][x] == 'Self-emp-inc') or (demp[2][x] == 'Without-pay') or (demp[2][x] == 'Never-worked'):
        demp[2][x] = 'Self-Emp/No-Pay'
    elif (demp[2][x] == 'Private'):
        demp[2][x] = 'Prv-Sector'

demp.to_csv("DimEmploymentFinal.csv", header=None, index=None);

dfc=pd.read_csv('adult-trainingcleaned.csv',header=None, sep=',')
dfc[0] = ""
dedu = dfc[[0,1,5]]

for x in range(0,(len(dedu[1]))):
    if (17<=dedu[1][x]<=20):
        dedu[1][x] = '17-20'
    elif (21<=dedu[1][x]<=30):
        dedu[1][x] = '21-30'
    elif (31<=dedu[1][x]<=40):
        dedu[1][x] = '31-40'
    elif (41<=dedu[1][x]<=50):
        dedu[1][x] = '41-50'
    elif (51<=dedu[1][x]<=60):
        dedu[1][x] = '51-60'
    elif (61<=dedu[1][x]<=70):
        dedu[1][x] = '61-70'
    elif (71<=dedu[1][x]<=80):
        dedu[1][x] = '71-80'
    elif (81<=dedu[1][x]<=90):
        dedu[1][x] = '81-90'
    
for x in range(0,(len(dedu[5]))):
    if (0<=dedu[5][x]<=9):
        dedu[5][x] = 'Low'
    elif (10<=dedu[5][x]<=13):
        dedu[5][x] = 'Medium'
    elif (14<=dedu[5][x]<=16):
        dedu[5][x] = 'High'

dedu.to_csv("DimEducationFinal.csv", header=None, index=None);

dfc=pd.read_csv('adult-trainingcleaned.csv',header=None, sep=',')
dfc[0] = ""
dinc = dfc[[0,15]]
dinc.to_csv("DimIncomeFinal.csv", header=None, index=None);

dfc=pd.read_csv('adult-trainingcleaned.csv',header=None, sep=',')
dfc[0] = ""
count = 0
for x in range(0,(len(dfc[1]))):
        dfc[1][x] = (count + 1)
        count = count+1
dfac = dfc[[0,1,1,1,3]]

dfac.to_csv("IncomeFactFinal.csv", header=None, index=None);
