/*
 * File modified from Lab4 from LMS for MidSem Project.
 *
 * File modified by - GAURAV CHAKRAVERTY for MidSem Project.
 *
 */
:setvar SqlSamplesSourceDataPath "D:\My Files\My Workspace\SQL Projects\MidSemProject\csv2import\"
:setvar DatabaseName "MidSemProject"

BULK INSERT [dbo].[DimEducation] FROM '$(SqlSamplesSourceDataPath)DimEducationFinal.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimEmployment] FROM '$(SqlSamplesSourceDataPath)DimEmploymentFinal.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[DimIncome] FROM '$(SqlSamplesSourceDataPath)DimIncomeFinal.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

BULK INSERT [dbo].[IncomeFact] FROM '$(SqlSamplesSourceDataPath)IncomeFactFinal.csv'
WITH (
    CHECK_CONSTRAINTS,
    --CODEPAGE='ACP',
    DATAFILETYPE='char',
    FIELDTERMINATOR=',',
    ROWTERMINATOR='\n',
    --KEEPIDENTITY,
    TABLOCK
);

