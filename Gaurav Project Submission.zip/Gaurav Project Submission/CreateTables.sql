/*
 * File modified from Lab4 from LMS for MidSem Project.
 *
 * File modified by - GAURAV CHAKRAVERTY for MidSem Project.
 *
 */


Use master
Go

PRINT '';
PRINT '*** Dropping Database';
GO

IF EXISTS (SELECT [name] FROM [master].[sys].[databases] WHERE [name] = N'MidSemProject')
DROP DATABASE MidSemProject;
GO

PRINT '';
PRINT '*** Creating Database';
GO

Create database MidSemProject
Go

Use MidSemProject
Go

PRINT '';
PRINT '*** Creating Table DimEducation';
GO

Create table DimEducation
(
EduID bigint primary key identity,
AgeGroup varchar(20) not null,
EduLevel varchar(20) not null,
)
Go

PRINT '';
PRINT '*** Creating Table DimEmployment';
GO

Create table DimEmployment
(
EmpID bigint primary key identity,
Occupation varchar(50) not null,
WorkSector varchar(25) not null,
Gender varchar(10) not null,
)
Go

PRINT '';
PRINT '*** Creating Table DimIncome';
GO

Create table DimIncome
(
IncomeID bigint primary key identity,
Income varchar(10)not null,
)
Go

PRINT '';
PRINT '*** Creating Table IncomeFact';
GO

Create Table IncomeFact
(
FactID bigint primary key identity,
EmpID bigint not null,
EduID bigint not null,
IncomeID bigint not null,
PeopleCount bigint not null,
)
Go

PRINT '';
PRINT '*** Add relation between fact table foreign keys to Primary keys of Dimensions';
GO

AlTER TABLE IncomeFact ADD CONSTRAINT 
FK_EmpID FOREIGN KEY (EmpID)REFERENCES DimEmployment(EmpID);
AlTER TABLE IncomeFact ADD CONSTRAINT 
FK_EduID FOREIGN KEY (EduID)REFERENCES DimEducation(EduID);
AlTER TABLE IncomeFact ADD CONSTRAINT 
FK_IncomeID FOREIGN KEY (IncomeID)REFERENCES DimIncome(IncomeID);
Go


